/**
 * 
 */
/**
 * 
 */
module Cofrinhodemoedas {
}