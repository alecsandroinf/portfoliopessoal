package cofre;

import java.util.ArrayList;
import java.util.Scanner;

// Classe abstrata Moeda
abstract class Moeda {
    double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    public abstract void info();
    public abstract double converter();
}

class Real extends Moeda {
    public Real(double valor) { super(valor); }
    @Override public void info() { System.out.println("Real - R$ " + valor); }
    @Override public double converter() { return valor; }
}

class Dolar extends Moeda {
    public Dolar(double valor) { super(valor); }
    @Override public void info() { System.out.println("Dólar - US$ " + valor); }
    @Override public double converter() { return valor * 5.50; }
}

class Euro extends Moeda {
    public Euro(double valor) { super(valor); }
    @Override public void info() { System.out.println("Euro - € " + valor); }
    @Override public double converter() { return valor * 6.00; }
}

class Cofrinho {
    ArrayList<Moeda> listaMoedas = new ArrayList<>();
    public void adicionar(Moeda m) { listaMoedas.add(m); }
    public void remover(Moeda m) { listaMoedas.remove(m); }
    public void listar() {
        if (listaMoedas.isEmpty()) System.out.println("Cofrinho vazio!");
        else for (Moeda m : listaMoedas) m.info();
    }
    public void listarComIndice() {
        if (listaMoedas.isEmpty()) System.out.println("Cofrinho vazio!");
        else for (int i = 0; i < listaMoedas.size(); i++) {
            System.out.print(i + " - "); listaMoedas.get(i).info();
        }
    }
    public double calcularTotal() {
        double total = 0;
        for (Moeda m : listaMoedas) total += m.converter();
        return total;
    }
}

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();
        int opcao;
        do {
            System.out.println("\n=== MENU COFRINHO ===");
            System.out.println("1 - Adicionar moeda");
            System.out.println("2 - Remover moeda");
            System.out.println("3 - Listar moedas");
            System.out.println("4 - Calcular total em Reais");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Escolha a moeda: 1-Real  2-Dólar  3-Euro");
                    int tipo = sc.nextInt();
                    System.out.print("Digite o valor: ");
                    double valor = sc.nextDouble();
                    if (tipo == 1) cofrinho.adicionar(new Real(valor));
                    else if (tipo == 2) cofrinho.adicionar(new Dolar(valor));
                    else if (tipo == 3) cofrinho.adicionar(new Euro(valor));
                    else System.out.println("Opção inválida!");
                    break;
                case 2:
                    if (cofrinho.listaMoedas.isEmpty()) {
                        System.out.println("Cofrinho vazio! Nada para remover.");
                    } else {
                        System.out.println("Escolha a moeda que deseja remover:");
                        cofrinho.listarComIndice();
                        System.out.print("Digite o índice da moeda: ");
                        int indice = sc.nextInt();
                        if (indice >= 0 && indice < cofrinho.listaMoedas.size()) {
                            Moeda removida = cofrinho.listaMoedas.get(indice);
                            cofrinho.remover(removida);
                            System.out.println("Moeda removida com sucesso!");
                        } else {
                            System.out.println("Índice inválido!");
                        }
                    }
                    break;
                case 3:
                    cofrinho.listar();
                    break;
                case 4:
                    System.out.println("Total em reais: R$ " + cofrinho.calcularTotal());
                    break;
                case 0:
                    System.out.println("Encerrando...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
        sc.close();
    }
}